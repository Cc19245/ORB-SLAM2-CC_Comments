﻿/**
* 理论学习
* 1、主线程是什么？什么时候开始、结束?
* 2、子线程如何创建？生命周期是？
* 3、thread 类的基本使用方法
* 
* 
* 代码演示
* 1、线程ID区分不同的线程
* 2、join, detach 区别
*/


#include <iostream>
// 使用多线程的头文件
#include <thread>  
#include <list>
#include <vector>
using namespace std;

void putInData()
{
    cout << "putInData 子线程 id = " << this_thread::get_id() << endl;
    for (int i = 0; i < 100; i++)
    {
        cout << "putInData 子线程：放入一个数据" << i << endl;
        //std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }
}


// 主线程从main函数入口开始执行
int main()
{
    cout << "主线程 id = " << this_thread::get_id() << endl;
    //std::list<int> dataQuene;

    //1、创建并开启线程，线程入口是 putInData，takeOutData 函数
    thread putThread(putInData);
  
    //2、join() 阻塞主线程并等待子线程执行完，当子线程执行完毕，join()就执行完毕，主线程继续往下执行
    //join意为汇合，子线程和主线程汇合
    //putThread.join();
 

    //3、传统多线程程序中，主线程要等待子线程执行完毕，然后自己才能向下执行
    //detach:分离，主线程不再与子线程汇合，不再等待子线程。!不建议使用
    //detach后，子线程和主线程失去关联，驻留在后台，由C++运行时库接管

    //putThread.detach();

    // 4、joinable()判断是否可以成功使用join()或者detach()
    //如果返回true，证明可以调用join()或者detach()
    //如果返回false，证明调用过join()或者detach()，join()和detach()都不能再调用了
    if (putThread.joinable())
    {
        cout << "可以调用join()或者detach()" << endl;
        putThread.join();
    }

    cout << "Hello, thread!" << endl;
    return 0;  //主线程结束，则整个进程执行完毕
}

